import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import Products from '../Products';

@Component({
  selector: 'app-mycart',
  templateUrl: './mycart.component.html',
  styleUrls: ['./mycart.component.css']
})
export class MycartComponent implements OnInit {

  constructor() { }

  @Output()
  placeorderEvent= new EventEmitter<string>();

  @Input()
  username:any;

  @Input()
  product:any;
  
  ngOnInit(): void {
  }

  placeorder(){
    this.placeorderEvent.emit('payment');
  }
  change(){
    this.placeorderEvent.emit('delivery');
  }

}
