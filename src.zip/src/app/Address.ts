export class Address{
    
    constructor(public addressLine1:any, public addressLine2:any, public city:any,public state:any,public country:any,public zipcode:any)
    {
    }
}