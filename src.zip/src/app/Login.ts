export default class Login{
    constructor(public username:string,public password:string){

    }

}