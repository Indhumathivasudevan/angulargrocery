export default class Status{
        constructor(public ptype:string,public uname:string){
            
        }
    }