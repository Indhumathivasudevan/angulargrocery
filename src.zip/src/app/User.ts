
import { Address } from "./Address";
import Login from "./Login";

export class User{
    constructor(public name:any,  public mobilenumber:any,public address:any,public login:any )
    {
    }
}