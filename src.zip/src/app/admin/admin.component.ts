import { Component, Input, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  user:any;

  @Input()
  username:any;

  constructor(private service:ServiceService) { }

  ngOnInit(): void {
    this.service.authenticate().subscribe({
      next: (data) => {
        console.log(data);
      },
    });
  }

}
